<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<p align="center">ᴜʟᴛʀᴀ ғᴏʀᴡᴀʀᴅ ʙᴏᴛ</p>


 ![github card](https://github-readme-stats.vercel.app/api/pin/?username=silicon-developer&repo=Ultra-Forward-Bot&theme=dark)

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

<h1 align="center">
 <b><a href="https://t.me/Auto_Forward_Public_Bot" target="/blank">ғᴏʀᴡᴀʀᴅ ʙᴏᴛ</a></>
</h1>

<p align="center"></p>

<b>- ᴄᴏɴɢɪғs ᴠᴀʀɪᴀʙʟᴇs</b>

* `BOT_TOKEN` - ɢᴇᴛ ʙᴏᴛ ᴛᴏᴋᴇɴ ғʀᴏᴍ <a href="https://t.me/BotFather" target="/blank">ʙᴏᴛ ғᴀᴛʜᴇʀ</a>
* `API_ID` - ɢᴇᴛ ᴀᴘɪ ɪᴅ ғʀᴏᴍ <a href="https://my.telegram.org" target="/blank">ᴛᴇʟᴇɢʀᴀᴍ ᴀᴜᴛʜ</a>
* `API_HASH` - ɢᴇᴛ ᴀᴘɪ ʜᴀsʜ ғʀᴏᴍ <a href="https://my.telegram.org" target="/blank">ᴛᴇʟᴇɢᴀᴍ ᴀᴜᴛʜ</a>
* `OWNER_ID` - ʙᴏᴛ ᴀᴅᴍɪɴ ᴏᴡɴᴇʀ ɪᴅ.
* `DATABASE_URI` - ᴍᴏɴɢᴏ ᴅᴀᴛᴀʙᴀsᴇ ᴜʀʟ ғʀᴏᴍ <a href="https://cloud.mongodb.com" target="/blank">ᴍᴏɴɢᴏ ᴅʙ</a>
* `DATABASE_NAME` - ʏᴏᴜʀ ᴅᴀᴛᴀ ʙᴀsᴇ ɴᴀᴍᴇ ᴏғ ᴍᴏɴɢᴏ ᴅʙ.
* `BOT_SESSION` - ʏᴏᴜʀ ʙᴏᴛ ɴᴀᴍᴇ. (Optional)
* `FORCE_SUB_CHANNEL` - ᴇɴᴛᴇʀ ᴛʜᴇ ʟɪɴᴋ ᴏғ ғ_ꜱᴜʙ ᴄʜᴀɴɴᴇʟ ᴡɪᴛʜ ʟɪᴋᴇ https://t.me/Silicon_Bot_Update 
</details>


<summary><h3>
- <b> ᴅᴇᴘʟᴏʏᴍᴇɴᴛ ᴍᴇᴛʜᴏᴅs </b>
</h3></summary>
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ 」─
</h3>

<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/Silicon-Developer/Utra-Forward-Bot">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy On Heroku">
</a></p>
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ᴋᴏʏᴇʙ 」─
</h3>
<p align="center"><a href="https://app.koyeb.com/deploy?type=git&repository=github.com/Silicon-Developer/Ultra-Forward-Bot&branch=main&name=main">
  <img src="https://www.koyeb.com/static/images/deploy/button.svg" alt="Deploy On Koyeb">
</a></p>
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʀᴀɪʟᴡᴀʏ 」─
</h3>
<p align="center"><a href="https://railway.app/deploy?template=https://github.com/Silicon-Developer/Ultra-Forward-Bot"">
     <img height="45px" src="https://railway.app/button.svg">
</a></p>
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʀᴇɴᴅᴇʀ 」─
</h3>
<p align="center"><a href="https://render.com/deploy?repo=https://github.com/Silicon-Developer/Ultra-Forward-Bot">
<img src="https://render.com/images/deploy-to-render-button.svg" alt="Deploy to Render">
</a></p> 
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ᴠᴘs 」─
</h3>
<p>
<pre>
git clone https://github.com/Silicon-Developer/Ultra-Forward-Bot.git
# Install Packages
pip3 install -U -r requirements.txt
Edit config.py with variables as given below then run bot
python3 bot.py
</pre>
</p>


### ғᴇᴀᴛᴜʀᴇs
 - ғᴏʀᴄᴇ sᴜʙsᴄʀɪʙᴇ
 - ғɪxᴇᴅ ʀᴇsᴛ ᴄᴏᴍᴍᴀɴᴅ
 - ᴛᴏᴛᴀʟ ᴍᴇsᴀᴀɢᴇs
 - ʙᴇsᴛ ᴜɪ/ᴜx
 - ᴇxᴀᴄᴛ ᴜᴘᴛɪᴍᴇ
 - ғᴏʀᴡᴀʀᴅɪɴɢ ᴡɪᴛʜ ᴜsᴇʀ ʙᴏᴛ
 - ʙʀᴏᴀᴅᴄᴀsᴛ sᴜᴘᴘᴏʀᴛ.
 - sᴇᴛ ᴄᴜsᴛᴏᴍ ʙᴜᴛᴛᴏɴ.
 - sᴇᴛ ᴄᴜsᴛᴏᴍ ᴄᴀᴘᴛɪᴏɴ.
 - sᴋɪᴘ ᴍᴇssᴀɢᴇs.
 - sᴋɪᴘ sᴜᴘʟɪᴄᴀᴛᴇ ᴍᴇssᴀɢᴇs.
 - ғɪʟᴛᴇʀ ᴛʏᴘᴇ ᴏғ ᴍᴇssᴀɢᴇs.
 - ʏᴏᴜ ᴄᴀɴ ᴀᴅᴅ ʏᴏᴜʀ ʙᴏᴛ ᴀɴᴅ ᴜsᴇʀ ʙᴏᴛ ᴛʜʀᴏᴜɢʜ ʟᴏɢɪɴ.
 - ғᴏʀᴡᴀʀᴅ ᴍᴇssᴀɢᴇs ғʀᴏᴍ ᴘᴜʙʟɪᴄ ᴄʜᴀɴɴᴇʟ ᴛᴏ ʏᴏᴜʀ ᴄʜᴀɴɴᴇʟ.
 - ғᴏʀᴡᴀʀᴅ ᴍᴇssᴀɢᴇ ғʀᴏᴍ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀɴɴᴇʟ ᴛᴏ ʏᴏᴜʀ ᴄʜᴀɴɴᴇʟ.
 - sᴋɪᴘ ᴍᴇssᴀɢᴇ ʙᴀsᴇᴅ ᴏɴ ᴇxᴛᴇɴsɪᴏɴ ᴀɴᴅ ᴋᴇʏᴡᴏʀᴅ.
 - ᴅᴇᴘʟᴏʏ ᴛᴏ ᴋᴏʏᴇʙ + ʜᴇʀᴏᴋᴜ + ʀᴀɪʟᴡᴀʏ.
 - ᴅᴇᴠᴇʟᴏᴘᴇʀ sᴜᴘᴘᴏʀᴛ 24 ×7 ᴀᴛ [sɪʟɪᴄᴏɴ ʙᴏᴛᴢ](https://t.me/Silicon/Botz).



### ᴀʟʟ ᴄᴏᴍᴍᴀɴᴅ

<hr><pre>
start - sᴛᴀʀᴛ ᴛʜᴇ ʙᴏᴛ.
forward - ᴛᴏ sᴛᴀʀᴛ ғᴏʀᴡᴀʀᴅ.
unequify - ᴅᴇʟᴇᴛᴇ ᴅᴜᴘʟɪᴄᴀᴛᴇ ғɪʟᴇs ɪɴ ᴄʜᴀɴɴᴇʟ.
settings - ᴄᴏɴғɪɢᴜʀᴇ ʏᴏᴜʀ sᴇᴛᴛɪɪɴɢs.
cancel - ᴄᴀɴᴄᴇʟ ᴏɴɢᴏɪɴɢ ғᴏʀᴡᴀʀᴅɪɴɢ.
reset - ᴛᴏ ʀᴇsᴇᴛ ᴀʟʟ sᴇᴛᴛɪɴɢs.
donate - ᴛᴏ sᴜᴘᴘᴏʀᴛ ᴅᴇᴠᴇʟᴏᴘᴇʀs.
resetall - ᴛᴏ ʀᴇsᴇᴛ ᴀʟʟ ᴜsᴇʀ sᴇᴛᴛɪɴɢs. (ᴏᴡɴᴇʀ ᴏɴʟʏ)
broadcast - ʙʀᴏᴀᴅᴄᴀsᴛ ᴍᴇssᴀɢᴇ ᴛᴏ ᴜsᴇʀ. (ᴏᴡɴᴇʀ ᴏɴʟʏ)
restart - ʀᴇsᴛᴀʀᴛ ᴛʜᴇ ʙᴏᴛ. (ᴏᴡɴᴇʀ ᴏɴʟʏ)
</pre><hr>


### Cʀᴇᴅɪᴛs

 - ᴛʜɪs ʀᴇᴘᴏ ᴡᴀs ᴅᴇsɪɴᴇᴅ ʙʏ [Sɪʟɪᴄᴏɴ ʙᴏᴛᴢ](htpps://t.me/Silicon_Bot_Update) 
 - ᴛʜɪs ʙᴏᴛ ᴡᴀs ғᴜʟʟʏ ᴅᴇᴠᴇʟᴏᴘᴇᴅ ʙʏ [sɪʟɪᴄᴏɴ ᴅᴇᴠᴇʟᴏᴘᴇʀ ⚠️](https://t.me/Silicon_Official)
 - ᴛʜᴀɴᴋs ᴛᴏ 𝗛𝗢𝗥𝗥𝗜𝗗
 - ᴛʜᴀɴᴋs ᴛᴏ ⚝𝗠𝗿.𝗦𝗣𝗜𝗗𝗬⚝
 - ᴛʜᴀɴᴋs ᴛᴏ ⌯ Ꭺɴᴏɴʏᴍᴏᴜꜱ | ×͜× |
 - ᴛʜɪs ʙᴏᴛ ʙᴀsᴇ ʀᴇᴘᴏ ᴡᴀs ᴘᴜʙʟɪᴄʟʟʏ ғᴏᴜɴᴅ ʙʏ ᴍᴇ ɪɴ ɴᴏᴛ ᴛʜᴇ sᴛᴀɢᴇ ᴛᴏ ᴅᴇᴘʟᴏʏ ɪᴛ ʜᴀs ᴀʟʟᴏᴛ ᴏғ ʙᴜɢs sᴏ ɴᴏ ᴄʀᴇᴅɪᴛ ᴛᴏ ʙᴀsᴇ ʀᴇᴘᴏ ᴀʟsᴏ ɪ ᴅɪᴅɴ'ᴛ ᴋɴᴏᴡ ʙᴀsᴇ ʀᴇᴘᴏ ᴏᴡɴᴇʀ.
